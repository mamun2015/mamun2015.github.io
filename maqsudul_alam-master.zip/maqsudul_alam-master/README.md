# Dr. Maqsudul Alam
Tribute page for Dr. Maqsudul Alam: Inventor of Jute Genome</br>
Dr. Maqsudul Alam achieved four milestones in genomics - sequencing the genomes of Papaya, Rubber, Jute and Fungus. Dr. Alam was a professor of the University of Hawaii at Manoa and a member of advisory board at Shahjalal University of Science and Technology, Bangladesh.
